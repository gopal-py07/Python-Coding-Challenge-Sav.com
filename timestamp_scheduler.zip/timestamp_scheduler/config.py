"""
Configuration file for global settings.
"""

API_URL = "https://ifconfig.co"
LOG_FILE = "execution.log"
