For the given problem solution , created own custome framework to get expected output
please follow the below deatils to run and test project

# To run the peoject timestamp_scheduler
step 1. downlaod and unzip folder
step 2. Open the terminal and navigate to the `timestamp_scheduler` directory, then use the following coomand:
step 3.
    ```
    python main.py 09:15:25,11:58:23,13:45:09,13:45:09,13:45:09,17:22:00,17:22:00
    ```
step 4. Check excution.log file fro desired o/p

=====================================================================================================================================

# Tests for timestamp_scheduler

To run the tests, open the terminal and navigate to the `timestamp_scheduler` directory, then use the following command:

python -m unittest discover tests/  # Run all tests together:

python test_generator.py   # ensuring tests run dynamically.

